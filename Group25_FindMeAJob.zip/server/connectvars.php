<?php
  // Define database connection constants
  define('DB_HOST', 'classmysql.engr.oregonstate.edu');
  define('DB_USER', 'cs340_choudhay');
  define('DB_PASSWORD', 'deadmentellnotales');
  define('DB_NAME', 'cs340_choudhay');
  define('CON_STRING', 'mysql:host=classmysql.engr.oregonstate.edu;dname=cs340_choudhay');
?>
